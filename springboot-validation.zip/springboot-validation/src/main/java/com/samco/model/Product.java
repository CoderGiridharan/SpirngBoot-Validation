package com.samco.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

@Entity
@Table(name = "person")
public class Product {
	
	@Id
	@NotNull
	private int id;
	@NotEmpty 
	@Size(min=2,message = "user name should have at least 2 character")
	private String productname;
	@NotEmpty
	private String producttype;

	public Product() {
		super();
	}

	public Product(int id, String productname, String producttype) {
		super();
		this.id = id;
		this.productname = productname;
		this.producttype = producttype;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

}
