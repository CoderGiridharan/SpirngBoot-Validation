package com.samco.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.samco.model.Product;
import com.samco.repository.ProductRepository;

@Service
public class ProductService {
	
	@Autowired
	private ProductRepository productRepository;
	
	public Product  saveProduct(Product product) {
		return productRepository.save(product);
	}
	
	
	public List<Product> getProduct() {
		return productRepository.findAll();
	}
	
	public Optional<Product> getById(int id){
		return productRepository.findById(id);
	}
	
	
	public void deleteById(int id) {
		productRepository.deleteById(id);
	}
	
	public void delete() {
		productRepository.deleteAll();
	}
}


